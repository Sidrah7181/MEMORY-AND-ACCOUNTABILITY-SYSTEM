## Packages
recharts | Data visualization for analytics
date-fns | Date formatting and manipulation
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind CSS classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["'DM Sans'", "sans-serif"],
  mono: ["'JetBrains Mono'", "monospace"],
}
