import { useState } from "react";
import { useCreateLearningItem } from "@/hooks/use-learning";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus } from "lucide-react";
import { Slider } from "@/components/ui/slider";

export function CreateLearningDialog() {
  const [open, setOpen] = useState(false);
  const [topic, setTopic] = useState("");
  const [category, setCategory] = useState("");
  const [difficulty, setDifficulty] = useState(3);
  
  const createItem = useCreateLearningItem();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createItem.mutate(
      { topic, category, difficulty },
      {
        onSuccess: () => {
          setOpen(false);
          setTopic("");
          setCategory("");
          setDifficulty(3);
        },
      }
    );
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="w-full gap-2 bg-white/5 hover:bg-white/10 text-white border border-white/10">
          <Plus className="h-4 w-4" />
          Add Item
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px] bg-card border-white/10 text-white">
        <DialogHeader>
          <DialogTitle>New Learning Item</DialogTitle>
          <DialogDescription>
            Add a topic to your spaced repetition queue.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6 pt-4">
          <div className="space-y-2">
            <Label htmlFor="topic">Topic</Label>
            <Input
              id="topic"
              placeholder="e.g. React hooks"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              className="bg-background border-white/10"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="category">Category</Label>
            <Input
              id="category"
              placeholder="e.g. Frontend Development"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="bg-background border-white/10"
              required
            />
          </div>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <Label>Difficulty (1-5)</Label>
              <span className="text-sm font-mono text-muted-foreground">{difficulty}</span>
            </div>
            <Slider
              value={[difficulty]}
              onValueChange={(vals) => setDifficulty(vals[0])}
              min={1}
              max={5}
              step={1}
              className="py-2"
            />
          </div>
          <DialogFooter>
            <Button type="submit" disabled={createItem.isPending}>
              {createItem.isPending ? "Adding..." : "Add to Queue"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
