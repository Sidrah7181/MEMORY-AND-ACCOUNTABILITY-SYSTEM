import { useState } from "react";
import { useReviewItem } from "@/hooks/use-learning";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Slider } from "@/components/ui/slider";
import { type LearningItem } from "@shared/schema";
import { Brain } from "lucide-react";

interface ReviewDialogProps {
  item: LearningItem | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ReviewDialog({ item, open, onOpenChange }: ReviewDialogProps) {
  const [rating, setRating] = useState(3);
  const reviewItem = useReviewItem();

  const handleSubmit = () => {
    if (!item) return;
    reviewItem.mutate(
      { 
        id: item.id, 
        data: { itemId: item.id, rating }
      },
      {
        onSuccess: () => {
          onOpenChange(false);
          setRating(3);
        },
      }
    );
  };

  if (!item) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[400px] bg-card border-white/10 text-white">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5 text-primary" />
            Review Session
          </DialogTitle>
        </DialogHeader>
        
        <div className="py-6 space-y-6">
          <div className="space-y-1 text-center">
            <h3 className="text-xl font-bold">{item.topic}</h3>
            <p className="text-sm text-muted-foreground">{item.category}</p>
          </div>

          <div className="space-y-4 p-4 rounded-lg bg-background/50 border border-white/5">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Confidence Rating</span>
              <span className="text-2xl font-mono font-bold text-primary">{rating}</span>
            </div>
            
            <Slider
              value={[rating]}
              onValueChange={(vals) => setRating(vals[0])}
              min={1}
              max={5}
              step={1}
            />
            
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>Forgot</span>
              <span>Vague</span>
              <span>Known</span>
              <span>Clear</span>
              <span>Mastered</span>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button onClick={handleSubmit} disabled={reviewItem.isPending} className="w-full">
            {reviewItem.isPending ? "Saving..." : "Complete Review"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
