import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type CreateLearningItemRequest, type ReviewItemRequest } from "@shared/routes";

// GET /api/learning
export function useLearningItems() {
  return useQuery({
    queryKey: [api.learning.list.path],
    queryFn: async () => {
      const res = await fetch(api.learning.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch learning items");
      return api.learning.list.responses[200].parse(await res.json());
    },
  });
}

// POST /api/learning
export function useCreateLearningItem() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: CreateLearningItemRequest) => {
      const validated = api.learning.create.input.parse(data);
      const res = await fetch(api.learning.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create item");
      return api.learning.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.learning.list.path] });
    },
  });
}

// POST /api/learning/:id/review
export function useReviewItem() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, data }: { id: number; data: ReviewItemRequest }) => {
      const validated = api.learning.review.input.parse(data);
      const url = buildUrl(api.learning.review.path, { id });
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to submit review");
      return api.learning.review.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.learning.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.analytics.get.path] });
    },
  });
}
