import { useState } from "react";
import { useHabits, useLogHabit, useDeleteHabit } from "@/hooks/use-habits";
import { useLearningItems } from "@/hooks/use-learning";
import { useAnalytics } from "@/hooks/use-analytics";
import { CreateHabitDialog } from "@/components/CreateHabitDialog";
import { CreateLearningDialog } from "@/components/CreateLearningDialog";
import { ReviewDialog } from "@/components/ReviewDialog";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  ResizableHandle, 
  ResizablePanel, 
  ResizablePanelGroup 
} from "@/components/ui/resizable";
import { 
  CheckCircle2, 
  Circle, 
  Clock, 
  Trash2, 
  TrendingUp, 
  Activity,
  Brain,
  Calendar,
  AlertCircle
} from "lucide-react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar
} from "recharts";
import { format, isToday } from "date-fns";
import type { LearningItem } from "@shared/schema";
import { cn } from "@/lib/utils";

export default function Dashboard() {
  const { data: habits, isLoading: loadingHabits } = useHabits();
  const { data: learningItems, isLoading: loadingLearning } = useLearningItems();
  const { data: analytics, isLoading: loadingAnalytics } = useAnalytics();
  
  const logHabit = useLogHabit();
  const deleteHabit = useDeleteHabit();
  
  const [selectedItemForReview, setSelectedItemForReview] = useState<LearningItem | null>(null);

  const handleHabitLog = (habitId: number) => {
    logHabit.mutate({
      habitId,
      date: new Date(),
      completed: true,
      durationMinutes: 0,
    });
  };

  const dueLearningItems = learningItems?.filter(item => 
    new Date(item.nextReview) <= new Date()
  ) || [];

  return (
    <div className="h-screen w-full bg-background text-foreground overflow-hidden flex flex-col">
      {/* Header */}
      <header className="h-14 border-b border-border flex items-center px-6 justify-between bg-card/50 backdrop-blur-sm z-10">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
            <Activity className="w-5 h-5 text-primary" />
          </div>
          <h1 className="text-lg font-bold tracking-tight">System<span className="text-muted-foreground font-normal">OS</span></h1>
        </div>
        <div className="text-sm font-mono text-muted-foreground">
          {format(new Date(), "EEE, MMM do yyyy")}
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 overflow-hidden">
        <ResizablePanelGroup direction="horizontal">
          
          {/* LEFT PANEL: Setup & Management */}
          <ResizablePanel defaultSize={25} minSize={20} className="bg-card/30 flex flex-col border-r border-border">
            <div className="p-4 border-b border-border bg-card/50">
              <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-4">Habit Stack</h2>
              <CreateHabitDialog />
            </div>
            
            <ScrollArea className="flex-1">
              <div className="p-4 space-y-2">
                {loadingHabits ? (
                  <div className="text-sm text-muted-foreground">Loading habits...</div>
                ) : habits?.map(habit => (
                  <div key={habit.id} className="group flex items-center justify-between p-3 rounded-lg border border-border/50 bg-card hover:border-border transition-colors">
                    <div>
                      <h3 className="font-medium text-sm">{habit.name}</h3>
                      <p className="text-xs text-muted-foreground capitalize">{habit.frequency}</p>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity text-destructive hover:text-destructive hover:bg-destructive/10"
                      onClick={() => deleteHabit.mutate(habit.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
                
                {habits?.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground text-sm border border-dashed border-border rounded-lg">
                    No habits defined yet.
                  </div>
                )}
              </div>
            </ScrollArea>
            
            <div className="p-4 border-t border-border bg-card/50">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Knowledge Base</h2>
              </div>
              <CreateLearningDialog />
            </div>
            
            <ScrollArea className="flex-1 max-h-[300px]">
              <div className="p-4 pt-0 space-y-2">
                {loadingLearning ? (
                  <div className="text-sm text-muted-foreground">Loading items...</div>
                ) : learningItems?.map(item => (
                  <div key={item.id} className="flex items-center justify-between p-3 rounded-lg border border-border/50 bg-card text-xs">
                    <div className="truncate pr-2">
                      <div className="font-medium truncate">{item.topic}</div>
                      <div className="text-muted-foreground">{item.category}</div>
                    </div>
                    <div className={cn(
                      "w-2 h-2 rounded-full",
                      item.retentionStrength > 80 ? "bg-green-500" :
                      item.retentionStrength > 50 ? "bg-yellow-500" : "bg-red-500"
                    )} />
                  </div>
                ))}
              </div>
            </ScrollArea>
          </ResizablePanel>

          <ResizableHandle className="bg-border w-[1px]" />

          {/* CENTER PANEL: Daily Action */}
          <ResizablePanel defaultSize={45} minSize={30} className="bg-background flex flex-col">
            <div className="p-6 flex-1 flex flex-col gap-6 overflow-hidden">
              <div>
                <h2 className="text-2xl font-bold mb-1">Daily Log</h2>
                <p className="text-muted-foreground text-sm">Track your progress for today.</p>
              </div>

              {/* Habits Checklist */}
              <div className="space-y-3">
                {loadingHabits ? (
                  <div className="space-y-3">
                    {[1, 2, 3].map(i => <div key={i} className="h-16 bg-muted/20 rounded-xl animate-pulse" />)}
                  </div>
                ) : habits?.map(habit => (
                  <div key={habit.id} className="flex items-center gap-4 p-4 rounded-xl border border-border bg-card hover:bg-card/80 transition-colors">
                    <button 
                      onClick={() => handleHabitLog(habit.id)}
                      disabled={logHabit.isPending}
                      className="group flex-shrink-0"
                    >
                      {/* Note: In a real app we'd check if logged today. For MVP, allowing multi-log */}
                      <Circle className="w-6 h-6 text-muted-foreground group-hover:text-primary transition-colors" />
                    </button>
                    <div className="flex-1">
                      <h3 className="font-medium">{habit.name}</h3>
                      {habit.description && <p className="text-sm text-muted-foreground">{habit.description}</p>}
                    </div>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground font-mono bg-muted/30 px-2 py-1 rounded">
                      <Clock className="w-3 h-3" />
                      {habit.frequency}
                    </div>
                  </div>
                ))}
              </div>

              <div className="my-4 h-[1px] bg-border w-full" />

              {/* Learning Review Queue */}
              <div className="flex-1 flex flex-col min-h-0">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="font-bold flex items-center gap-2">
                    <Brain className="w-5 h-5 text-primary" />
                    Review Queue
                    <span className="bg-primary/20 text-primary text-xs px-2 py-0.5 rounded-full font-mono">
                      {dueLearningItems.length}
                    </span>
                  </h2>
                </div>

                {dueLearningItems.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 overflow-y-auto pr-2 custom-scrollbar">
                    {dueLearningItems.map(item => (
                      <div key={item.id} className="p-4 rounded-xl border border-border bg-card flex flex-col justify-between gap-4">
                        <div>
                          <span className="text-xs font-mono text-muted-foreground mb-1 block">{item.category}</span>
                          <h3 className="font-bold leading-tight">{item.topic}</h3>
                        </div>
                        <div className="flex items-center justify-between mt-auto">
                          <div className="flex gap-1">
                            {Array.from({length: 5}).map((_, i) => (
                              <div key={i} className={cn(
                                "w-1 h-3 rounded-full",
                                i < item.currentConfidence ? "bg-primary" : "bg-muted"
                              )} />
                            ))}
                          </div>
                          <Button size="sm" variant="secondary" onClick={() => setSelectedItemForReview(item)}>
                            Review
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground border-2 border-dashed border-border rounded-xl">
                    <CheckCircle2 className="w-12 h-12 mb-2 text-green-500/50" />
                    <p>All caught up!</p>
                  </div>
                )}
              </div>
            </div>
          </ResizablePanel>

          <ResizableHandle className="bg-border w-[1px]" />

          {/* RIGHT PANEL: Analytics */}
          <ResizablePanel defaultSize={30} minSize={20} className="bg-card/30 flex flex-col border-l border-border">
            <ScrollArea className="flex-1">
              <div className="p-6 space-y-8">
                <div>
                  <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-4 flex items-center gap-2">
                    <TrendingUp className="w-4 h-4" /> Performance
                  </h2>
                  
                  {loadingAnalytics ? (
                    <div className="h-48 bg-muted/10 rounded animate-pulse" />
                  ) : (
                    <div className="space-y-6">
                      <div className="bg-card border border-border rounded-xl p-4">
                        <h3 className="text-sm font-medium mb-4">Habit Consistency</h3>
                        <div className="h-[200px] w-full">
                          <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={analytics?.habitCompletion}>
                              <CartesianGrid strokeDasharray="3 3" vertical={false} />
                              <XAxis dataKey="name" fontSize={10} tickLine={false} axisLine={false} />
                              <YAxis fontSize={10} tickLine={false} axisLine={false} unit="%" />
                              <Tooltip 
                                contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))' }}
                                itemStyle={{ color: 'hsl(var(--foreground))' }}
                              />
                              <Bar dataKey="rate" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                            </BarChart>
                          </ResponsiveContainer>
                        </div>
                      </div>

                      <div className="bg-card border border-border rounded-xl p-4">
                        <h3 className="text-sm font-medium mb-4">Retention Curve</h3>
                        <div className="h-[200px] w-full">
                          <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={analytics?.learningRetention}>
                              <CartesianGrid strokeDasharray="3 3" vertical={false} />
                              <XAxis dataKey="topic" fontSize={10} tickLine={false} axisLine={false} />
                              <YAxis fontSize={10} tickLine={false} axisLine={false} unit="%" />
                              <Tooltip 
                                contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))' }}
                                itemStyle={{ color: 'hsl(var(--foreground))' }}
                              />
                              <Line 
                                type="monotone" 
                                dataKey="strength" 
                                stroke="hsl(var(--success))" 
                                strokeWidth={2} 
                                dot={false}
                              />
                            </LineChart>
                          </ResponsiveContainer>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                <div className="p-4 bg-muted/20 rounded-xl border border-white/5">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="w-5 h-5 text-warning shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-bold text-warning mb-1">System Insight</h4>
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        Consistency on "Read 10 pages" has dropped 20% this week. Consider moving it to earlier in the day.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </ScrollArea>
          </ResizablePanel>
        </ResizablePanelGroup>
      </div>

      <ReviewDialog 
        item={selectedItemForReview} 
        open={!!selectedItemForReview} 
        onOpenChange={(open) => !open && setSelectedItemForReview(null)} 
      />
    </div>
  );
}
