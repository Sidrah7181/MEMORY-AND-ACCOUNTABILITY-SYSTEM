import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // === HABITS ===
  app.get(api.habits.list.path, async (req, res) => {
    const habits = await storage.getHabits();
    res.json(habits);
  });

  app.post(api.habits.create.path, async (req, res) => {
    try {
      const input = api.habits.create.input.parse(req.body);
      const habit = await storage.createHabit(input);
      res.status(201).json(habit);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid input", errors: err.errors });
        return;
      }
      throw err;
    }
  });

  app.put(api.habits.update.path, async (req, res) => {
    const id = parseInt(req.params.id);
    const updates = api.habits.update.input.parse(req.body);
    const habit = await storage.updateHabit(id, updates);
    res.json(habit);
  });

  app.delete(api.habits.delete.path, async (req, res) => {
    const id = parseInt(req.params.id);
    await storage.deleteHabit(id);
    res.status(204).send();
  });

  app.get(api.habits.getLogs.path, async (req, res) => {
    const id = parseInt(req.params.id);
    const logs = await storage.getHabitLogs(id);
    res.json(logs);
  });

  // === LOGS ===
  app.post(api.logs.create.path, async (req, res) => {
    try {
      const input = api.logs.create.input.parse(req.body);
      const log = await storage.createLog(input);
      res.status(201).json(log);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid input", errors: err.errors });
        return;
      }
      throw err;
    }
  });

  // === LEARNING ===
  app.get(api.learning.list.path, async (req, res) => {
    const items = await storage.getLearningItems();
    res.json(items);
  });

  app.post(api.learning.create.path, async (req, res) => {
    try {
      const input = api.learning.create.input.parse(req.body);
      const item = await storage.createLearningItem(input);
      res.status(201).json(item);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid input", errors: err.errors });
        return;
      }
      throw err;
    }
  });

  app.post(api.learning.review.path, async (req, res) => {
    try {
      const input = api.learning.review.input.parse(req.body);
      const item = await storage.createReview(input);
      res.json(item);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid input", errors: err.errors });
        return;
      }
      throw err;
    }
  });

  // === ANALYTICS ===
  app.get(api.analytics.get.path, async (req, res) => {
    const habits = await storage.getHabits();
    const logs = await storage.getAllLogs();
    const learningItems = await storage.getLearningItems();

    // Simple analytics calculation
    const habitCompletion = habits.map(h => {
      const hLogs = logs.filter(l => l.habitId === h.id);
      const completed = hLogs.filter(l => l.completed).length;
      return {
        name: h.name,
        rate: hLogs.length > 0 ? (completed / hLogs.length) * 100 : 0
      };
    });

    const learningRetention = learningItems.map(i => ({
      topic: i.topic,
      strength: i.retentionStrength
    }));

    res.json({ habitCompletion, learningRetention });
  });

  // Seed Data
  const existingHabits = await storage.getHabits();
  if (existingHabits.length === 0) {
    await storage.createHabit({ name: "Morning Run", description: "30 mins cardio", frequency: "daily" });
    await storage.createHabit({ name: "Deep Work", description: "4 hours focused coding", frequency: "daily" });
    await storage.createHabit({ name: "Read Research", description: "1 paper per week", frequency: "weekly" });
    
    await storage.createLearningItem({ topic: "Advanced SQL", category: "Programming", difficulty: 4 });
    await storage.createLearningItem({ topic: "Cognitive Psychology", category: "Science", difficulty: 3 });
  }

  return httpServer;
}
