import { db } from "./db";
import {
  habits, habitLogs, learningItems, learningReviews,
  type InsertHabit, type InsertLog, type InsertLearningItem, type InsertReview,
  type Habit, type HabitLog, type LearningItem, type LearningReview
} from "@shared/schema";
import { eq, desc, and, gte, lte } from "drizzle-orm";

export interface IStorage {
  // Habits
  getHabits(): Promise<Habit[]>;
  getHabit(id: number): Promise<Habit | undefined>;
  createHabit(habit: InsertHabit): Promise<Habit>;
  updateHabit(id: number, updates: Partial<InsertHabit>): Promise<Habit>;
  deleteHabit(id: number): Promise<void>;

  // Logs
  createLog(log: InsertLog): Promise<HabitLog>;
  getHabitLogs(habitId: number): Promise<HabitLog[]>;
  getAllLogs(): Promise<HabitLog[]>;

  // Learning
  getLearningItems(): Promise<LearningItem[]>;
  getLearningItem(id: number): Promise<LearningItem | undefined>;
  createLearningItem(item: InsertLearningItem): Promise<LearningItem>;
  createReview(review: InsertReview): Promise<LearningItem>; // Returns updated item
}

export class DatabaseStorage implements IStorage {
  async getHabits(): Promise<Habit[]> {
    return await db.select().from(habits).orderBy(desc(habits.createdAt));
  }

  async getHabit(id: number): Promise<Habit | undefined> {
    const [habit] = await db.select().from(habits).where(eq(habits.id, id));
    return habit;
  }

  async createHabit(insertHabit: InsertHabit): Promise<Habit> {
    const [habit] = await db.insert(habits).values(insertHabit).returning();
    return habit;
  }

  async updateHabit(id: number, updates: Partial<InsertHabit>): Promise<Habit> {
    const [habit] = await db.update(habits).set(updates).where(eq(habits.id, id)).returning();
    return habit;
  }

  async deleteHabit(id: number): Promise<void> {
    await db.delete(habits).where(eq(habits.id, id));
  }

  async createLog(insertLog: InsertLog): Promise<HabitLog> {
    const [log] = await db.insert(habitLogs).values(insertLog).returning();
    return log;
  }

  async getHabitLogs(habitId: number): Promise<HabitLog[]> {
    return await db.select().from(habitLogs).where(eq(habitLogs.habitId, habitId)).orderBy(desc(habitLogs.date));
  }

  async getAllLogs(): Promise<HabitLog[]> {
    return await db.select().from(habitLogs).orderBy(desc(habitLogs.date));
  }

  async getLearningItems(): Promise<LearningItem[]> {
    return await db.select().from(learningItems).orderBy(learningItems.nextReview);
  }

  async getLearningItem(id: number): Promise<LearningItem | undefined> {
    const [item] = await db.select().from(learningItems).where(eq(learningItems.id, id));
    return item;
  }

  async createLearningItem(insertItem: InsertLearningItem): Promise<LearningItem> {
    const [item] = await db.insert(learningItems).values(insertItem).returning();
    return item;
  }

  async createReview(insertReview: InsertReview): Promise<LearningItem> {
    // Insert review
    await db.insert(learningReviews).values(insertReview);

    // Calculate Ebbinghaus / SM-2 algorithm update
    // Simple version: increase interval based on rating (1-5)
    // Rating 1: reset, Rating 5: large jump
    const item = await this.getLearningItem(insertReview.itemId);
    if (!item) throw new Error("Item not found");

    const now = new Date();
    let nextDate = new Date();
    let retention = item.retentionStrength;

    if (insertReview.rating === 1) {
      retention = 0;
      nextDate.setDate(now.getDate() + 1); // Review tomorrow
    } else {
      retention += insertReview.rating; // Simplified growth
      // Interval = 2 ^ (rating - 1) days approx for demo
      const daysToAdd = Math.max(1, Math.pow(2, insertReview.rating - 1));
      nextDate.setDate(now.getDate() + daysToAdd);
    }

    const [updatedItem] = await db.update(learningItems)
      .set({
        lastReview: now,
        nextReview: nextDate,
        retentionStrength: retention,
        currentConfidence: insertReview.rating
      })
      .where(eq(learningItems.id, item.id))
      .returning();

    return updatedItem;
  }
}

export const storage = new DatabaseStorage();
