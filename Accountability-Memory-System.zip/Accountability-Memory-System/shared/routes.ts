import { z } from 'zod';
import { insertHabitSchema, insertLogSchema, insertLearningItemSchema, insertReviewSchema, habits, learningItems, habitLogs } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  habits: {
    list: {
      method: 'GET' as const,
      path: '/api/habits',
      responses: {
        200: z.array(z.custom<typeof habits.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/habits',
      input: insertHabitSchema,
      responses: {
        201: z.custom<typeof habits.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/habits/:id',
      input: insertHabitSchema.partial(),
      responses: {
        200: z.custom<typeof habits.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/habits/:id',
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
    getLogs: {
      method: 'GET' as const,
      path: '/api/habits/:id/logs',
      responses: {
        200: z.array(z.custom<typeof habitLogs.$inferSelect>()),
      },
    }
  },
  logs: {
    create: {
      method: 'POST' as const,
      path: '/api/logs',
      input: insertLogSchema,
      responses: {
        201: z.custom<typeof habitLogs.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  learning: {
    list: {
      method: 'GET' as const,
      path: '/api/learning',
      responses: {
        200: z.array(z.custom<typeof learningItems.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/learning',
      input: insertLearningItemSchema,
      responses: {
        201: z.custom<typeof learningItems.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    review: {
      method: 'POST' as const,
      path: '/api/learning/:id/review',
      input: insertReviewSchema,
      responses: {
        200: z.custom<typeof learningItems.$inferSelect>(), // Returns updated item
        404: errorSchemas.notFound,
      },
    },
  },
  analytics: {
    get: {
      method: 'GET' as const,
      path: '/api/analytics',
      responses: {
        200: z.object({
          habitCompletion: z.array(z.object({ name: z.string(), rate: z.number() })),
          learningRetention: z.array(z.object({ topic: z.string(), strength: z.number() })),
        }),
      },
    },
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
