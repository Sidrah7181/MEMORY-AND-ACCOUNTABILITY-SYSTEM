import { pgTable, text, serial, integer, boolean, timestamp, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === HABITS ===
export const habits = pgTable("habits", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  frequency: text("frequency").notNull().default("daily"), // daily, weekly
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const habitLogs = pgTable("habit_logs", {
  id: serial("id").primaryKey(),
  habitId: integer("habit_id").notNull().references(() => habits.id),
  date: timestamp("date").notNull(), // Using timestamp for easier date handling
  completed: boolean("completed").notNull().default(false),
  durationMinutes: integer("duration_minutes").default(0),
  notes: text("notes"),
});

// === LEARNING & EBBINGHAUS ===
export const learningItems = pgTable("learning_items", {
  id: serial("id").primaryKey(),
  topic: text("topic").notNull(),
  category: text("category").notNull(),
  difficulty: integer("difficulty").notNull().default(1), // 1-5
  currentConfidence: integer("current_confidence").notNull().default(0), // 1-5
  lastReview: timestamp("last_review"),
  nextReview: timestamp("next_review").notNull().defaultNow(),
  retentionStrength: integer("retention_strength").notNull().default(0), // Calculated metric
  createdAt: timestamp("created_at").defaultNow(),
});

export const learningReviews = pgTable("learning_reviews", {
  id: serial("id").primaryKey(),
  itemId: integer("item_id").notNull().references(() => learningItems.id),
  date: timestamp("date").defaultNow(),
  rating: integer("rating").notNull(), // 1-5 confidence at time of review
});

// === SCHEMAS ===
export const insertHabitSchema = createInsertSchema(habits).omit({ id: true, createdAt: true });
export const insertLogSchema = createInsertSchema(habitLogs).omit({ id: true });
export const insertLearningItemSchema = createInsertSchema(learningItems).omit({ id: true, lastReview: true, nextReview: true, retentionStrength: true, createdAt: true, currentConfidence: true });
export const insertReviewSchema = createInsertSchema(learningReviews).omit({ id: true, date: true });

// === TYPES ===
export type Habit = typeof habits.$inferSelect;
export type InsertHabit = z.infer<typeof insertHabitSchema>;
export type HabitLog = typeof habitLogs.$inferSelect;
export type InsertLog = z.infer<typeof insertLogSchema>;

export type LearningItem = typeof learningItems.$inferSelect;
export type InsertLearningItem = z.infer<typeof insertLearningItemSchema>;
export type LearningReview = typeof learningReviews.$inferSelect;
export type InsertReview = z.infer<typeof insertReviewSchema>;

// === API CONTRACT TYPES ===
export type CreateHabitRequest = InsertHabit;
export type UpdateHabitRequest = Partial<InsertHabit>;
export type LogHabitRequest = InsertLog;

export type CreateLearningItemRequest = InsertLearningItem;
export type ReviewItemRequest = InsertReview;
